import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertFeedingScheduleSchema, type InsertFeedingSchedule, type FeedingSchedule } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Clock, Utensils, Calendar, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/utils";

export default function FeedingSchedules() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: schedules = [], isLoading } = useQuery<FeedingSchedule[]>({
    queryKey: ["/api/feeding-schedules"],
  });

  const { data: cages = [] } = useQuery({
    queryKey: ["/api/cages"],
  });

  const form = useForm<InsertFeedingSchedule>({
    resolver: zodResolver(insertFeedingScheduleSchema),
    defaultValues: {
      feedType: "",
      quantity: "",
      feedingTime: "08:00",
      frequency: "daily",
      isActive: true,
      notes: "",
      cageId: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertFeedingSchedule) => {
      await apiRequest("/api/feeding-schedules", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/feeding-schedules"] });
      form.reset();
      setIsDialogOpen(false);
      toast({
        title: "Feeding schedule created",
        description: "Feeding schedule has been added successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const toggleScheduleMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number; isActive: boolean }) => {
      await apiRequest(`/api/feeding-schedules/${id}`, "PUT", { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/feeding-schedules"] });
      toast({
        title: "Schedule updated",
        description: "Feeding schedule status has been updated.",
      });
    },
  });

  const onSubmit = (data: InsertFeedingSchedule) => {
    createMutation.mutate(data);
  };

  const getFrequencyColor = (frequency: string) => {
    switch (frequency) {
      case "daily":
        return "bg-green-100 text-green-800";
      case "twice_daily":
        return "bg-blue-100 text-blue-800";
      case "weekly":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Feeding Schedules</h1>
          <p className="text-muted-foreground">
            Manage feeding schedules and track feed consumption
          </p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Feeding Schedule
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add Feeding Schedule</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="cageId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cage</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || ""}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select cage" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="">All cages</SelectItem>
                            {cages.map((cage: any) => (
                              <SelectItem key={cage.id} value={cage.cageNumber}>
                                Cage {cage.cageNumber} - {cage.location}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="feedType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Feed Type</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select feed type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="starter">Starter Feed</SelectItem>
                            <SelectItem value="grower">Grower Feed</SelectItem>
                            <SelectItem value="layer">Layer Feed</SelectItem>
                            <SelectItem value="finisher">Finisher Feed</SelectItem>
                            <SelectItem value="supplement">Supplement</SelectItem>
                            <SelectItem value="treats">Treats</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Quantity (kg)</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" step="0.1" placeholder="5.0" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="feedingTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Feeding Time</FormLabel>
                        <FormControl>
                          <Input {...field} type="time" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="frequency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Frequency</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select frequency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="twice_daily">Twice Daily</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea {...field} value={field.value || ""} placeholder="Additional feeding instructions..." />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                      <div className="space-y-0.5">
                        <FormLabel>Active Schedule</FormLabel>
                        <div className="text-sm text-muted-foreground">
                          Enable this feeding schedule
                        </div>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <Button type="submit" disabled={createMutation.isPending} className="w-full">
                  {createMutation.isPending ? "Adding..." : "Add Feeding Schedule"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {schedules.map((schedule) => (
          <Card key={schedule.id} className={schedule.isActive ? "" : "opacity-60"}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">
                  {schedule.cageId ? `Cage ${schedule.cageId}` : "All Cages"}
                </CardTitle>
                <Switch
                  checked={schedule.isActive}
                  onCheckedChange={(checked) => 
                    toggleScheduleMutation.mutate({ id: schedule.id, isActive: checked })
                  }
                />
              </div>
              <CardDescription>
                <div className="flex items-center gap-2">
                  <Utensils className="w-4 h-4" />
                  {schedule.feedType}
                </div>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{schedule.feedingTime}</span>
                </div>
                <Badge className={getFrequencyColor(schedule.frequency)}>
                  {schedule.frequency.replace("_", " ")}
                </Badge>
              </div>
              
              <div className="text-sm">
                <strong>Quantity:</strong> {schedule.quantity} kg
              </div>
              
              {schedule.notes && (
                <div className="text-sm text-muted-foreground">
                  {schedule.notes}
                </div>
              )}
              
              <div className="text-xs text-muted-foreground">
                Created: {formatDate(schedule.createdAt!)}
              </div>
            </CardContent>
          </Card>
        ))}
        
        {schedules.length === 0 && (
          <Card className="col-span-full">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Calendar className="w-12 h-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No feeding schedules</h3>
              <p className="text-muted-foreground text-center mb-4">
                Create your first feeding schedule to automate feed management
              </p>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Feeding Schedule
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Today's Feeding Schedule</CardTitle>
          <CardDescription>
            Active feeding schedules for today
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Time</TableHead>
                <TableHead>Cage</TableHead>
                <TableHead>Feed Type</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {schedules
                .filter(s => s.isActive && (s.frequency === 'daily' || s.frequency === 'twice_daily'))
                .map((schedule) => (
                  <TableRow key={schedule.id}>
                    <TableCell className="font-medium">{schedule.feedingTime}</TableCell>
                    <TableCell>{schedule.cageId || "All Cages"}</TableCell>
                    <TableCell>{schedule.feedType}</TableCell>
                    <TableCell>{schedule.quantity} kg</TableCell>
                    <TableCell>
                      <Badge className="bg-yellow-100 text-yellow-800">
                        <Clock className="w-3 h-3 mr-1" />
                        Pending
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              {schedules.filter(s => s.isActive && (s.frequency === 'daily' || s.frequency === 'twice_daily')).length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground">
                    No feeding schedules for today
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}