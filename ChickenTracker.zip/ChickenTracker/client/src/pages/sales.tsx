import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSalesSchema, type Sales, type InsertSales } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatCurrency, getStatusColor } from "@/lib/utils";
import { Plus, ShoppingCart, Calendar, DollarSign, Tag, Eye, Edit, Trash2 } from "lucide-react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";

export default function SalesPage() {
  const { toast } = useToast();

  const { data: sales, isLoading } = useQuery<Sales[]>({
    queryKey: ["/api/sales"],
  });

  const form = useForm<InsertSales>({
    resolver: zodResolver(insertSalesSchema),
    defaultValues: {
      date: new Date(),
      customerName: "",
      quantity: 0,
      pricePerEgg: "0.50",
      totalAmount: "0.00",
      paymentStatus: "paid",
    },
  });

  const createSaleMutation = useMutation({
    mutationFn: async (data: InsertSales) => {
      const response = await apiRequest("POST", "/api/sales", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      form.reset({
        date: new Date(),
        customerName: "",
        quantity: 0,
        pricePerEgg: "0.50",
        totalAmount: "0.00",
        paymentStatus: "paid",
      });
      toast({
        title: "Success",
        description: "Sale recorded successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to record sale",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertSales) => {
    createSaleMutation.mutate(data);
  };

  // Watch quantity and price to calculate total
  const watchedQuantity = form.watch("quantity");
  const watchedPrice = form.watch("pricePerEgg");

  // Update total amount when quantity or price changes
  React.useEffect(() => {
    const total = (watchedQuantity * parseFloat(watchedPrice || "0")).toFixed(2);
    form.setValue("totalAmount", total);
  }, [watchedQuantity, watchedPrice, form]);

  // Calculate statistics
  const today = new Date();
  const startOfWeek = new Date(today);
  startOfWeek.setDate(today.getDate() - today.getDay());
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

  const todaySales = sales?.filter(s => {
    const sDate = new Date(s.date);
    return sDate.toDateString() === today.toDateString();
  }) || [];

  const weeklySales = sales?.filter(s => {
    const sDate = new Date(s.date);
    return sDate >= startOfWeek;
  }) || [];

  const monthlySales = sales?.filter(s => {
    const sDate = new Date(s.date);
    return sDate >= startOfMonth;
  }) || [];

  const todayCount = todaySales.reduce((sum, s) => sum + s.quantity, 0);
  const todayRevenue = todaySales.reduce((sum, s) => sum + parseFloat(s.totalAmount), 0);
  const weeklyCount = weeklySales.reduce((sum, s) => sum + s.quantity, 0);
  const weeklyRevenue = weeklySales.reduce((sum, s) => sum + parseFloat(s.totalAmount), 0);
  const monthlyCount = monthlySales.reduce((sum, s) => sum + s.quantity, 0);
  const monthlyRevenue = monthlySales.reduce((sum, s) => sum + parseFloat(s.totalAmount), 0);

  const avgPrice = sales && sales.length > 0 ? 
    sales.reduce((sum, s) => sum + parseFloat(s.pricePerEgg), 0) / sales.length : 0;

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Sales Management</h2>
      </div>

      {/* Sales Entry Form */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">New Sale Entry</h3>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        {...field}
                        value={field.value instanceof Date ? field.value.toISOString().split('T')[0] : field.value}
                        onChange={(e) => field.onChange(new Date(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="customerName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Customer</FormLabel>
                    <FormControl>
                      <Input placeholder="Customer name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="Number of eggs" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="pricePerEgg"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Price per Egg</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="0.50" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex items-end">
                <Button 
                  type="submit" 
                  className="w-full bg-farm-green hover:bg-farm-dark"
                  disabled={createSaleMutation.isPending}
                >
                  {createSaleMutation.isPending ? "Recording..." : "Record Sale"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Sales Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Today's Sales</p>
                <p className="text-2xl font-bold text-gray-900">{todayCount} eggs</p>
              </div>
              <div className="bg-green-50 p-3 rounded-lg">
                <ShoppingCart className="text-green-600 text-xl" />
              </div>
            </div>
            <p className="text-sm text-green-600 mt-2">
              Revenue: {formatCurrency(todayRevenue)}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">This Week</p>
                <p className="text-2xl font-bold text-gray-900">{weeklyCount} eggs</p>
              </div>
              <div className="bg-blue-50 p-3 rounded-lg">
                <Calendar className="text-blue-600 text-xl" />
              </div>
            </div>
            <p className="text-sm text-green-600 mt-2">
              Revenue: {formatCurrency(weeklyRevenue)}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">This Month</p>
                <p className="text-2xl font-bold text-gray-900">{monthlyCount} eggs</p>
              </div>
              <div className="bg-purple-50 p-3 rounded-lg">
                <DollarSign className="text-purple-600 text-xl" />
              </div>
            </div>
            <p className="text-sm text-green-600 mt-2">
              Revenue: {formatCurrency(monthlyRevenue)}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Average Price</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(avgPrice)}</p>
              </div>
              <div className="bg-yellow-50 p-3 rounded-lg">
                <Tag className="text-yellow-600 text-xl" />
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-2">Per egg pricing</p>
          </CardContent>
        </Card>
      </div>

      {/* Sales History Table */}
      <Card>
        <CardContent className="p-0">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Sales History</h3>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Unit Price</TableHead>
                  <TableHead>Total Amount</TableHead>
                  <TableHead>Payment Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sales?.map((sale) => (
                  <TableRow key={sale.id}>
                    <TableCell>{formatDate(sale.date)}</TableCell>
                    <TableCell className="font-medium">{sale.customerName}</TableCell>
                    <TableCell>{sale.quantity} eggs</TableCell>
                    <TableCell>{formatCurrency(sale.pricePerEgg)}</TableCell>
                    <TableCell className="font-medium">{formatCurrency(sale.totalAmount)}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(sale.paymentStatus)}`}>
                        {sale.paymentStatus}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-800">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {(!sales || sales.length === 0) && (
            <div className="p-12 text-center">
              <ShoppingCart className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No sales records</h3>
              <p className="text-gray-500 mb-4">Start recording your egg sales to track revenue.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
