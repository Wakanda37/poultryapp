import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { formatDateTime, getStatusColor } from "@/lib/utils";
import { Warehouse, Plus, Minus, AlertTriangle, TrendingUp, Settings } from "lucide-react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";

interface InventoryBalance {
  balance: number;
}

interface Inventory {
  id: number;
  date: string;
  movementType: string;
  quantity: number;
  balanceAfter: number;
  notes?: string;
  relatedId?: number;
}

interface DashboardStats {
  todayEggs: number;
  todayEggsSold: number;
  currentInventory: number;
}

export default function InventoryPage() {
  const { data: inventoryBalance } = useQuery<InventoryBalance>({
    queryKey: ["/api/inventory/balance"],
  });

  const { data: inventory, isLoading } = useQuery<Inventory[]>({
    queryKey: ["/api/inventory"],
  });

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const currentStock = inventoryBalance?.balance || 0;
  const todayAdded = stats?.todayEggs || 0;
  const todayRemoved = stats?.todayEggsSold || 0;
  const isLowStock = currentStock < 500;

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Inventory Management</h2>
        <Button className="bg-farm-green hover:bg-farm-dark">
          <Settings className="mr-2 h-4 w-4" />
          Adjust Inventory
        </Button>
      </div>

      {/* Current Inventory Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="bg-green-50 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Warehouse className="text-green-600 text-2xl" />
              </div>
              <p className="text-sm text-gray-600 mb-1">Current Stock</p>
              <p className="text-4xl font-bold text-gray-900">{currentStock}</p>
              <p className="text-sm text-gray-600 mt-1">eggs available</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="bg-blue-50 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Plus className="text-blue-600 text-2xl" />
              </div>
              <p className="text-sm text-gray-600 mb-1">Total Added Today</p>
              <p className="text-4xl font-bold text-gray-900">{todayAdded}</p>
              <p className="text-sm text-gray-600 mt-1">eggs collected</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="bg-red-50 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Minus className="text-red-600 text-2xl" />
              </div>
              <p className="text-sm text-gray-600 mb-1">Total Sold Today</p>
              <p className="text-4xl font-bold text-gray-900">{todayRemoved}</p>
              <p className="text-sm text-gray-600 mt-1">eggs sold</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Inventory Alerts */}
      {isLowStock && (
        <Card className="bg-orange-50 border-orange-200 mb-6">
          <CardContent className="p-6">
            <div className="flex items-start">
              <div className="bg-orange-100 p-2 rounded-lg mr-4">
                <AlertTriangle className="text-orange-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-orange-900 mb-2">Inventory Alert</h3>
                <p className="text-orange-800 mb-3">
                  Current stock ({currentStock} eggs) is below the recommended minimum of 500 eggs. 
                  Consider adjusting collection schedule or sales strategy.
                </p>
                <div className="flex space-x-3">
                  <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                    Adjust Minimum
                  </Button>
                  <Button variant="outline" className="border-orange-600 text-orange-600 hover:bg-orange-50">
                    Dismiss
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Inventory Movement History */}
      <Card className="mb-6">
        <CardContent className="p-0">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Recent Inventory Movement</h3>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Balance After</TableHead>
                  <TableHead>Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {inventory?.slice(0, 10).map((movement) => (
                  <TableRow key={movement.id}>
                    <TableCell>{formatDateTime(movement.date)}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        movement.movementType === 'production' 
                          ? 'bg-green-100 text-green-800' 
                          : movement.movementType === 'sale'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {movement.movementType}
                      </span>
                    </TableCell>
                    <TableCell className={movement.quantity > 0 ? 'text-green-600' : 'text-red-600'}>
                      {movement.quantity > 0 ? '+' : ''}{movement.quantity}
                    </TableCell>
                    <TableCell className="font-medium">{movement.balanceAfter}</TableCell>
                    <TableCell className="max-w-xs truncate">{movement.notes || "-"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {(!inventory || inventory.length === 0) && (
            <div className="p-12 text-center">
              <Warehouse className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No inventory movements</h3>
              <p className="text-gray-500 mb-4">Inventory movements will appear here as you record production and sales.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Inventory Analytics and Settings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Weekly Inventory Trend</h3>
            <div className="text-center py-12 text-gray-500">
              <TrendingUp className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-lg font-medium">Weekly inventory trend chart</p>
              <p className="text-sm mt-2">Shows stock levels, production, and sales over time</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Inventory Settings</h3>
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-gray-700 mb-2">Minimum Stock Alert</Label>
                <div className="flex items-center space-x-2">
                  <Input type="number" defaultValue="500" className="flex-1" />
                  <span className="text-sm text-gray-500">eggs</span>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-700 mb-2">Maximum Stock Capacity</Label>
                <div className="flex items-center space-x-2">
                  <Input type="number" defaultValue="2000" className="flex-1" />
                  <span className="text-sm text-gray-500">eggs</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">Email Alerts</span>
                <Switch defaultChecked />
              </div>
              <Button className="w-full bg-farm-green hover:bg-farm-dark">
                Save Settings
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
