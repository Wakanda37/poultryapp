import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Egg, TrendingUp, BarChart3, Users } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Poultry Farm Manager
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Complete solution for managing your poultry farm with user accounts, 
            egg tracking, sales management, and profit analysis with expense tracking.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg"
          >
            Sign In to Get Started
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="text-center">
            <CardHeader>
              <Egg className="w-12 h-12 mx-auto text-yellow-600 mb-4" />
              <CardTitle>Track Eggs & Hens</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Monitor your daily egg production and manage your flock with detailed tracking
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <TrendingUp className="w-12 h-12 mx-auto text-green-600 mb-4" />
              <CardTitle>Sales Management</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Record sales at $0.132 per egg with automatic profit calculations
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <BarChart3 className="w-12 h-12 mx-auto text-blue-600 mb-4" />
              <CardTitle>Expense Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Track feed, medicine, and other expenses for accurate profit/loss reporting
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Users className="w-12 h-12 mx-auto text-purple-600 mb-4" />
              <CardTitle>User Accounts</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Secure user authentication with individual balance and resource tracking
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8 mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Key Features</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">Resource Management</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Track total eggs in your inventory</li>
                <li>• Monitor number of hens in your flock</li>
                <li>• Manage your farm's financial balance</li>
                <li>• Add resources directly to user accounts</li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">Financial Tracking</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Automatic profit/loss calculations</li>
                <li>• Weekly and monthly reports</li>
                <li>• Expense tracking for feeds and medicine</li>
                <li>• Real-time balance updates</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to Start Managing Your Farm?</h2>
          <p className="text-gray-600 mb-6">
            Join today and take control of your poultry business with our comprehensive management system.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="bg-green-600 hover:bg-green-700 text-white px-8 py-3"
          >
            Sign In Now
          </Button>
        </div>
      </div>
    </div>
  );
}