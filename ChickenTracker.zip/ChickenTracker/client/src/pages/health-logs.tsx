import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertHealthLogSchema, type InsertHealthLog, type HealthLog } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Activity, AlertTriangle, CheckCircle, XCircle, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatCurrency, getStatusColor } from "@/lib/utils";

export default function HealthLogs() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: healthLogs = [], isLoading } = useQuery<HealthLog[]>({
    queryKey: ["/api/health-logs"],
  });

  const { data: chickens = [] } = useQuery({
    queryKey: ["/api/chickens"],
  });

  const { data: cages = [] } = useQuery({
    queryKey: ["/api/cages"],
  });

  const form = useForm<InsertHealthLog>({
    resolver: zodResolver(insertHealthLogSchema),
    defaultValues: {
      healthStatus: "healthy",
      symptoms: "",
      treatment: "",
      medication: "",
      veterinarianNotes: "",
      cost: "0.00",
      cageId: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertHealthLog) => {
      await apiRequest("/api/health-logs", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/health-logs"] });
      form.reset();
      setIsDialogOpen(false);
      toast({
        title: "Health log created",
        description: "Health record has been added successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertHealthLog) => {
    createMutation.mutate(data);
  };

  const getHealthStatusIcon = (status: string) => {
    switch (status) {
      case "healthy":
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case "sick":
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case "quarantine":
        return <XCircle className="w-4 h-4 text-red-600" />;
      case "deceased":
        return <XCircle className="w-4 h-4 text-gray-600" />;
      default:
        return <Activity className="w-4 h-4 text-blue-600" />;
    }
  };

  const getHealthStatusColor = (status: string) => {
    switch (status) {
      case "healthy":
        return "bg-green-100 text-green-800";
      case "sick":
        return "bg-yellow-100 text-yellow-800";
      case "quarantine":
        return "bg-red-100 text-red-800";
      case "deceased":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-blue-100 text-blue-800";
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Health Logs</h1>
          <p className="text-muted-foreground">
            Track chicken health, treatments, and veterinary records
          </p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Health Record
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add Health Record</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="chickenId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Chicken (Optional)</FormLabel>
                        <Select onValueChange={(value) => field.onChange(value ? parseInt(value) : null)} value={field.value?.toString() || ""}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select chicken" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="">No specific chicken</SelectItem>
                            {chickens.map((chicken: any) => (
                              <SelectItem key={chicken.id} value={chicken.id.toString()}>
                                {chicken.breed} - {chicken.tag}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="cageId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cage</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || ""}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select cage" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="">All cages</SelectItem>
                            {cages.map((cage: any) => (
                              <SelectItem key={cage.id} value={cage.cageNumber}>
                                Cage {cage.cageNumber} - {cage.location}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="healthStatus"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Health Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select health status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="healthy">Healthy</SelectItem>
                          <SelectItem value="sick">Sick</SelectItem>
                          <SelectItem value="quarantine">Quarantine</SelectItem>
                          <SelectItem value="deceased">Deceased</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="symptoms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Symptoms</FormLabel>
                      <FormControl>
                        <Textarea {...field} value={field.value || ""} placeholder="Describe observed symptoms..." />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="treatment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Treatment</FormLabel>
                        <FormControl>
                          <Textarea {...field} value={field.value || ""} placeholder="Treatment provided..." />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="medication"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Medication</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ""} placeholder="Medication given..." />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="veterinarianNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Veterinarian Notes</FormLabel>
                      <FormControl>
                        <Textarea {...field} value={field.value || ""} placeholder="Professional veterinary notes..." />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="cost"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Treatment Cost</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" step="0.01" placeholder="0.00" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="nextCheckupDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Next Checkup Date</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="datetime-local" 
                            value={field.value ? new Date(field.value).toISOString().slice(0, 16) : ""}
                            onChange={(e) => field.onChange(e.target.value ? new Date(e.target.value) : null)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button type="submit" disabled={createMutation.isPending} className="w-full">
                  {createMutation.isPending ? "Adding..." : "Add Health Record"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Health Records</CardTitle>
          <CardDescription>
            Complete health history and treatment records
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Chicken/Cage</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Symptoms</TableHead>
                <TableHead>Treatment</TableHead>
                <TableHead>Cost</TableHead>
                <TableHead>Next Checkup</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {healthLogs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell>{formatDate(log.createdAt!)}</TableCell>
                  <TableCell>
                    {log.chickenId ? `Chicken #${log.chickenId}` : log.cageId ? `Cage ${log.cageId}` : "General"}
                  </TableCell>
                  <TableCell>
                    <Badge className={getHealthStatusColor(log.healthStatus)}>
                      <div className="flex items-center gap-1">
                        {getHealthStatusIcon(log.healthStatus)}
                        {log.healthStatus}
                      </div>
                    </Badge>
                  </TableCell>
                  <TableCell className="max-w-xs truncate">
                    {log.symptoms || "-"}
                  </TableCell>
                  <TableCell className="max-w-xs truncate">
                    {log.treatment || "-"}
                  </TableCell>
                  <TableCell>{formatCurrency(log.cost || "0")}</TableCell>
                  <TableCell>
                    {log.nextCheckupDate ? (
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        {formatDate(log.nextCheckupDate)}
                      </div>
                    ) : "-"}
                  </TableCell>
                </TableRow>
              ))}
              {healthLogs.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground">
                    No health records found. Add your first health log to get started.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}