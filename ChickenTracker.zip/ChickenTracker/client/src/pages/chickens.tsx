import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertChickenSchema, type Chicken, type InsertChicken } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getStatusColor, formatDate } from "@/lib/utils";
import { Egg, Plus, Eye, Heart } from "lucide-react";

export default function Chickens() {
  const [filter, setFilter] = useState({
    status: "",
    ageGroup: "",
    production: "",
    search: "",
  });
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  const { toast } = useToast();

  const { data: chickens, isLoading } = useQuery<Chicken[]>({
    queryKey: ["/api/chickens"],
  });

  const form = useForm<InsertChicken>({
    resolver: zodResolver(insertChickenSchema),
    defaultValues: {
      identifier: "",
      breed: "",
      status: "healthy",
      ageInMonths: 0,
      weeklyEggAverage: "0.0",
      lastHealthCheck: new Date(),
      notes: "",
    },
  });

  const createChickenMutation = useMutation({
    mutationFn: async (data: InsertChicken) => {
      const response = await apiRequest("POST", "/api/chickens", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chickens"] });
      setIsAddDialogOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Chicken added successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add chicken",
        variant: "destructive",
      });
    },
  });

  const filteredChickens = chickens?.filter((chicken) => {
    if (filter.status && chicken.status !== filter.status) return false;
    if (filter.search && !chicken.identifier.toLowerCase().includes(filter.search.toLowerCase()) &&
        !chicken.breed.toLowerCase().includes(filter.search.toLowerCase())) return false;
    
    if (filter.ageGroup) {
      if (filter.ageGroup === "chicks" && chicken.ageInMonths > 8) return false;
      if (filter.ageGroup === "young" && (chicken.ageInMonths <= 8 || chicken.ageInMonths > 20)) return false;
      if (filter.ageGroup === "adult" && chicken.ageInMonths <= 20) return false;
    }

    if (filter.production) {
      const avg = parseFloat(chicken.weeklyEggAverage);
      if (filter.production === "high" && avg < 5) return false;
      if (filter.production === "average" && (avg < 3 || avg >= 5)) return false;
      if (filter.production === "low" && avg >= 3) return false;
    }

    return true;
  });

  const onSubmit = (data: InsertChicken) => {
    createChickenMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-32 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Chicken Management</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-farm-green hover:bg-farm-dark">
              <Plus className="mr-2 h-4 w-4" />
              Add Chicken
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Add New Chicken</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="identifier"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Identifier</FormLabel>
                      <FormControl>
                        <Input placeholder="CH-001" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="breed"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Breed</FormLabel>
                      <FormControl>
                        <Input placeholder="Rhode Island Red" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Health Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="healthy">Healthy</SelectItem>
                          <SelectItem value="monitoring">Monitoring</SelectItem>
                          <SelectItem value="sick">Sick</SelectItem>
                          <SelectItem value="treatment">Under Treatment</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="ageInMonths"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Age (months)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="weeklyEggAverage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Weekly Egg Average</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1" 
                          placeholder="5.2" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Additional notes..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-farm-green hover:bg-farm-dark"
                    disabled={createChickenMutation.isPending}
                  >
                    {createChickenMutation.isPending ? "Adding..." : "Add Chicken"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filter Controls */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label className="text-sm font-medium text-gray-700 mb-2">Health Status</Label>
              <Select value={filter.status} onValueChange={(value) => setFilter(prev => ({ ...prev, status: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Status</SelectItem>
                  <SelectItem value="healthy">Healthy</SelectItem>
                  <SelectItem value="monitoring">Monitoring</SelectItem>
                  <SelectItem value="sick">Sick</SelectItem>
                  <SelectItem value="treatment">Under Treatment</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium text-gray-700 mb-2">Age Group</Label>
              <Select value={filter.ageGroup} onValueChange={(value) => setFilter(prev => ({ ...prev, ageGroup: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="All Ages" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Ages</SelectItem>
                  <SelectItem value="chicks">Chicks (0-8 weeks)</SelectItem>
                  <SelectItem value="young">Young (9-20 weeks)</SelectItem>
                  <SelectItem value="adult">Adult (20+ weeks)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium text-gray-700 mb-2">Production Level</Label>
              <Select value={filter.production} onValueChange={(value) => setFilter(prev => ({ ...prev, production: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="All Levels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Levels</SelectItem>
                  <SelectItem value="high">High Producer (5+ eggs/week)</SelectItem>
                  <SelectItem value="average">Average Producer (3-5 eggs/week)</SelectItem>
                  <SelectItem value="low">Low Producer (&lt;3 eggs/week)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium text-gray-700 mb-2">Search</Label>
              <Input 
                placeholder="Search chickens..." 
                value={filter.search}
                onChange={(e) => setFilter(prev => ({ ...prev, search: e.target.value }))}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chicken Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredChickens?.map((chicken) => (
          <Card key={chicken.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="bg-yellow-50 p-3 rounded-full">
                    <Egg className="text-yellow-600" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{chicken.identifier}</h3>
                    <p className="text-sm text-gray-500">{chicken.breed}</p>
                  </div>
                </div>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(chicken.status)}`}>
                  {chicken.status}
                </span>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Age:</span>
                  <span className="font-medium">{chicken.ageInMonths} months</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Weekly Eggs:</span>
                  <span className="font-medium">{chicken.weeklyEggAverage} avg</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Last Check:</span>
                  <span className="font-medium">{formatDate(chicken.lastHealthCheck)}</span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Eye className="w-4 h-4 mr-1" />
                    View
                  </Button>
                  <Button size="sm" className="flex-1 bg-farm-green hover:bg-farm-dark">
                    <Heart className="w-4 h-4 mr-1" />
                    Health
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredChickens?.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <Egg className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No chickens found</h3>
            <p className="text-gray-500 mb-4">
              {chickens?.length === 0 
                ? "Get started by adding your first chicken to the flock."
                : "Try adjusting your filters to see more chickens."
              }
            </p>
            {chickens?.length === 0 && (
              <Button onClick={() => setIsAddDialogOpen(true)} className="bg-farm-green hover:bg-farm-dark">
                <Plus className="mr-2 h-4 w-4" />
                Add Your First Chicken
              </Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
