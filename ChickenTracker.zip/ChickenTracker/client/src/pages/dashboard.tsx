import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Egg, 
  Calendar, 
  DollarSign, 
  Warehouse, 
  Plus, 
  ShoppingCart, 
  Heart, 
  TrendingUp,
  ArrowUp,
  AlertTriangle
} from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/utils";

interface DashboardStats {
  totalChickens: number;
  todayEggs: number;
  todayEggsSold: number;
  todayRevenue: string;
  currentInventory: number;
  weeklyProduction: number;
  weeklyRevenue: string;
  monthlyProduction: number;
  monthlyRevenue: string;
  avgDailyProduction: number;
}

interface EggProduction {
  id: number;
  date: string;
  collectionTime: string;
  eggCount: number;
  notes?: string;
}

interface Sales {
  id: number;
  date: string;
  customerName: string;
  quantity: number;
  totalAmount: string;
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: recentProduction } = useQuery<EggProduction[]>({
    queryKey: ["/api/production"],
  });

  const { data: recentSales } = useQuery<Sales[]>({
    queryKey: ["/api/sales"],
  });

  if (statsLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-20 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Chickens</p>
                <p className="text-3xl font-bold text-gray-900">{stats?.totalChickens || 0}</p>
              </div>
              <div className="bg-blue-50 p-3 rounded-lg">
                <Egg className="text-blue-600 text-xl" />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-sm text-green-600 font-medium">
                <ArrowUp className="inline w-3 h-3" /> Active flock
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Today's Eggs</p>
                <p className="text-3xl font-bold text-gray-900">{stats?.todayEggs || 0}</p>
              </div>
              <div className="bg-yellow-50 p-3 rounded-lg">
                <Calendar className="text-yellow-600 text-xl" />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-sm text-gray-600">
                Average: <span className="font-medium">{stats?.avgDailyProduction || 0}/day</span>
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Eggs Sold Today</p>
                <p className="text-3xl font-bold text-gray-900">{stats?.todayEggsSold || 0}</p>
              </div>
              <div className="bg-green-50 p-3 rounded-lg">
                <DollarSign className="text-green-600 text-xl" />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-sm text-green-600 font-medium">
                Revenue: {formatCurrency(stats?.todayRevenue || "0")}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Current Inventory</p>
                <p className="text-3xl font-bold text-gray-900">{stats?.currentInventory || 0}</p>
              </div>
              <div className="bg-purple-50 p-3 rounded-lg">
                <Warehouse className="text-purple-600 text-xl" />
              </div>
            </div>
            <div className="mt-2">
              {(stats?.currentInventory || 0) < 500 && (
                <span className="text-sm text-orange-600 font-medium">
                  <AlertTriangle className="inline w-3 h-3" /> Low stock alert
                </span>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button
              variant="outline"
              className="h-20 flex-col space-y-2 border-dashed border-2 hover:border-farm-green hover:bg-green-50"
              onClick={() => window.location.href = "/production"}
            >
              <Plus className="text-2xl text-gray-400" />
              <span className="text-sm font-medium">Record Egg Production</span>
            </Button>
            <Button
              variant="outline"
              className="h-20 flex-col space-y-2 border-dashed border-2 hover:border-farm-green hover:bg-green-50"
              onClick={() => window.location.href = "/sales"}
            >
              <ShoppingCart className="text-2xl text-gray-400" />
              <span className="text-sm font-medium">Record Sale</span>
            </Button>
            <Button
              variant="outline"
              className="h-20 flex-col space-y-2 border-dashed border-2 hover:border-farm-green hover:bg-green-50"
              onClick={() => window.location.href = "/chickens"}
            >
              <Heart className="text-2xl text-gray-400" />
              <span className="text-sm font-medium">Health Check</span>
            </Button>
            <Button
              variant="outline"
              className="h-20 flex-col space-y-2 border-dashed border-2 hover:border-farm-green hover:bg-green-50"
              onClick={() => window.location.href = "/inventory"}
            >
              <TrendingUp className="text-2xl text-gray-400" />
              <span className="text-sm font-medium">View Reports</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Production</h3>
            <div className="space-y-4">
              {recentProduction?.slice(0, 5).map((record) => (
                <div key={record.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                  <div className="flex items-center space-x-3">
                    <div className="bg-blue-50 p-2 rounded-lg">
                      <Calendar className="text-blue-600" size={16} />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{formatDate(record.date)}</p>
                      <p className="text-sm text-gray-500">{record.collectionTime} Collection</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">{record.eggCount} eggs</p>
                    <p className="text-sm text-green-600">Recorded</p>
                  </div>
                </div>
              ))}
              {(!recentProduction || recentProduction.length === 0) && (
                <p className="text-gray-500 text-center py-4">No recent production records</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Sales</h3>
            <div className="space-y-4">
              {recentSales?.slice(0, 5).map((sale) => (
                <div key={sale.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                  <div className="flex items-center space-x-3">
                    <div className="bg-green-50 p-2 rounded-lg">
                      <ShoppingCart className="text-green-600" size={16} />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{sale.customerName}</p>
                      <p className="text-sm text-gray-500">{formatDate(sale.date)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">{sale.quantity} eggs</p>
                    <p className="text-sm text-green-600">{formatCurrency(sale.totalAmount)}</p>
                  </div>
                </div>
              ))}
              {(!recentSales || recentSales.length === 0) && (
                <p className="text-gray-500 text-center py-4">No recent sales records</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
