import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertEggProductionSchema, type EggProduction, type InsertEggProduction } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatDateTime } from "@/lib/utils";
import { Plus, Calendar, TrendingUp, CalendarDays, BarChart3, Edit, Trash2 } from "lucide-react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";

export default function Production() {
  const { toast } = useToast();

  const { data: production, isLoading } = useQuery<EggProduction[]>({
    queryKey: ["/api/production"],
  });

  const form = useForm<InsertEggProduction>({
    resolver: zodResolver(insertEggProductionSchema),
    defaultValues: {
      date: new Date(),
      collectionTime: "morning",
      eggCount: 0,
      notes: "",
    },
  });

  const createProductionMutation = useMutation({
    mutationFn: async (data: InsertEggProduction) => {
      const response = await apiRequest("POST", "/api/production", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/production"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      form.reset({
        date: new Date(),
        collectionTime: "morning",
        eggCount: 0,
        notes: "",
      });
      toast({
        title: "Success",
        description: "Production record added successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add production record",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertEggProduction) => {
    createProductionMutation.mutate(data);
  };

  // Calculate statistics
  const today = new Date();
  const startOfWeek = new Date(today);
  startOfWeek.setDate(today.getDate() - today.getDay());
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

  const todayProduction = production?.filter(p => {
    const pDate = new Date(p.date);
    return pDate.toDateString() === today.toDateString();
  }) || [];

  const weeklyProduction = production?.filter(p => {
    const pDate = new Date(p.date);
    return pDate >= startOfWeek;
  }) || [];

  const monthlyProduction = production?.filter(p => {
    const pDate = new Date(p.date);
    return pDate >= startOfMonth;
  }) || [];

  const todayTotal = todayProduction.reduce((sum, p) => sum + p.eggCount, 0);
  const weeklyTotal = weeklyProduction.reduce((sum, p) => sum + p.eggCount, 0);
  const monthlyTotal = monthlyProduction.reduce((sum, p) => sum + p.eggCount, 0);
  const dailyAverage = monthlyTotal / today.getDate();

  // Group production by date for daily totals
  const productionByDate = production?.reduce((acc, record) => {
    const date = new Date(record.date).toDateString();
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(record);
    return acc;
  }, {} as Record<string, EggProduction[]>) || {};

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Egg Production Tracking</h2>
      </div>

      {/* Production Entry Form */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Entry</h3>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        {...field}
                        value={field.value instanceof Date ? field.value.toISOString().split('T')[0] : field.value}
                        onChange={(e) => field.onChange(new Date(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="collectionTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Collection Time</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="morning">Morning</SelectItem>
                        <SelectItem value="afternoon">Afternoon</SelectItem>
                        <SelectItem value="evening">Evening</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="eggCount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Number of Eggs</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="Enter egg count" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex items-end">
                <Button 
                  type="submit" 
                  className="w-full bg-farm-green hover:bg-farm-dark"
                  disabled={createProductionMutation.isPending}
                >
                  {createProductionMutation.isPending ? "Recording..." : "Record Eggs"}
                </Button>
              </div>
            </form>
          </Form>
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem className="mt-4">
                <FormLabel>Notes (optional)</FormLabel>
                <FormControl>
                  <Textarea placeholder="Additional notes about this collection..." {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </CardContent>
      </Card>

      {/* Production Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="bg-blue-50 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Calendar className="text-blue-600 text-xl" />
              </div>
              <p className="text-sm text-gray-600 mb-1">This Week</p>
              <p className="text-3xl font-bold text-gray-900">{weeklyTotal}</p>
              <p className="text-sm text-green-600 mt-1">
                <TrendingUp className="inline w-3 h-3" /> Weekly total
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="bg-green-50 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <CalendarDays className="text-green-600 text-xl" />
              </div>
              <p className="text-sm text-gray-600 mb-1">This Month</p>
              <p className="text-3xl font-bold text-gray-900">{monthlyTotal}</p>
              <p className="text-sm text-green-600 mt-1">
                <TrendingUp className="inline w-3 h-3" /> Monthly total
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="bg-purple-50 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <BarChart3 className="text-purple-600 text-xl" />
              </div>
              <p className="text-sm text-gray-600 mb-1">Daily Average</p>
              <p className="text-3xl font-bold text-gray-900">{Math.round(dailyAverage)}</p>
              <p className="text-sm text-gray-600 mt-1">Last 30 days</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Production History Table */}
      <Card>
        <CardContent className="p-0">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Production History</h3>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Collection Time</TableHead>
                  <TableHead>Eggs Collected</TableHead>
                  <TableHead>Daily Total</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {production?.map((record) => {
                  const dailyRecords = productionByDate[new Date(record.date).toDateString()] || [];
                  const dailyTotal = dailyRecords.reduce((sum, r) => sum + r.eggCount, 0);
                  
                  return (
                    <TableRow key={record.id}>
                      <TableCell className="font-medium">{formatDate(record.date)}</TableCell>
                      <TableCell className="capitalize">{record.collectionTime}</TableCell>
                      <TableCell>{record.eggCount}</TableCell>
                      <TableCell className="font-medium">{dailyTotal}</TableCell>
                      <TableCell className="max-w-xs truncate">{record.notes || "-"}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-800">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
          
          {(!production || production.length === 0) && (
            <div className="p-12 text-center">
              <Calendar className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No production records</h3>
              <p className="text-gray-500 mb-4">Start tracking your daily egg production.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
