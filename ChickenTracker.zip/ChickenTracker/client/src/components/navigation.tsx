import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Egg, 
  Plus, 
  DollarSign, 
  Warehouse 
} from "lucide-react";

const navigationItems = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  { path: "/chickens", label: "Chickens", icon: Egg },
  { path: "/production", label: "Production", icon: Plus },
  { path: "/sales", label: "Sales", icon: DollarSign },
  { path: "/inventory", label: "Inventory", icon: Warehouse },
];

export default function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-8 overflow-x-auto">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <Link key={item.path} href={item.path}>
                <button
                  className={`py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap flex items-center space-x-2 ${
                    isActive
                      ? "border-farm-green text-farm-green"
                      : "border-transparent text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <Icon size={16} />
                  <span>{item.label}</span>
                </button>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
