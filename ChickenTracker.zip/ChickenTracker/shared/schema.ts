import { pgTable, text, serial, integer, timestamp, decimal, boolean, varchar, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  farmName: varchar("farm_name").default("My Poultry Farm"),
  balance: varchar("balance").default("1000.00"), // User's money balance
  totalEggs: integer("total_eggs").default(0), // Total eggs in inventory
  totalHens: integer("total_hens").default(0), // Total number of hens
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const chickens = pgTable("chickens", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  identifier: text("identifier").notNull(), // CH-001, CH-002, etc.
  breed: text("breed").notNull(),
  status: text("status").notNull().default("healthy"), // healthy, sick, monitoring, treatment
  ageInMonths: integer("age_in_months").notNull(),
  weeklyEggAverage: decimal("weekly_egg_average", { precision: 3, scale: 1 }).default("0.0"),
  lastHealthCheck: timestamp("last_health_check").defaultNow(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const eggProduction = pgTable("egg_production", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  date: timestamp("date").notNull(),
  collectionTime: text("collection_time").notNull(), // morning, afternoon, evening
  eggCount: integer("egg_count").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  date: timestamp("date").notNull(),
  customerName: text("customer_name").notNull(),
  quantity: integer("quantity").notNull(),
  pricePerEgg: decimal("price_per_egg", { precision: 4, scale: 3 }).notNull().default("0.132"),
  totalAmount: decimal("total_amount", { precision: 8, scale: 2 }).notNull(),
  paymentStatus: text("payment_status").notNull().default("paid"), // paid, pending, overdue
  createdAt: timestamp("created_at").defaultNow(),
});

export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  date: timestamp("date").notNull(),
  category: text("category").notNull(), // feed, medicine, equipment, utilities, labor, maintenance
  description: text("description").notNull(),
  amount: decimal("amount", { precision: 8, scale: 2 }).notNull(),
  supplier: text("supplier"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  date: timestamp("date").notNull(),
  movementType: text("movement_type").notNull(), // production, sale, adjustment
  quantity: integer("quantity").notNull(), // positive for additions, negative for removals
  balanceAfter: integer("balance_after").notNull(),
  notes: text("notes"),
  relatedId: integer("related_id"), // references production or sales record
  createdAt: timestamp("created_at").defaultNow(),
});

export const weeklyReports = pgTable("weekly_reports", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  weekStartDate: timestamp("week_start_date").notNull(),
  weekEndDate: timestamp("week_end_date").notNull(),
  totalRevenue: decimal("total_revenue", { precision: 10, scale: 2 }).notNull(),
  totalExpenses: decimal("total_expenses", { precision: 10, scale: 2 }).notNull(),
  netProfit: decimal("net_profit", { precision: 10, scale: 2 }).notNull(),
  eggsProduced: integer("eggs_produced").notNull(),
  eggsSold: integer("eggs_sold").notNull(),
  averagePrice: decimal("average_price", { precision: 4, scale: 3 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("info"), // info, warning, success, error
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Health tracking for chickens
export const healthLogs = pgTable("health_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  chickenId: integer("chicken_id").references(() => chickens.id),
  cageId: varchar("cage_id"),
  healthStatus: varchar("health_status").notNull(), // healthy, sick, quarantine, deceased
  symptoms: text("symptoms"),
  treatment: text("treatment"),
  medication: varchar("medication"),
  veterinarianNotes: text("veterinarian_notes"),
  nextCheckupDate: timestamp("next_checkup_date"),
  cost: varchar("cost").default("0.00"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Feeding schedule and tracking
export const feedingSchedules = pgTable("feeding_schedules", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  cageId: varchar("cage_id"),
  feedType: varchar("feed_type").notNull(),
  quantity: varchar("quantity").notNull(),
  feedingTime: varchar("feeding_time").notNull(), // e.g., "08:00"
  frequency: varchar("frequency").notNull(), // daily, twice_daily, weekly
  isActive: boolean("is_active").default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const feedingLogs = pgTable("feeding_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  scheduleId: integer("schedule_id").references(() => feedingSchedules.id),
  cageId: varchar("cage_id"),
  feedType: varchar("feed_type").notNull(),
  quantityGiven: varchar("quantity_given").notNull(),
  feedingTime: timestamp("feeding_time").notNull(),
  cost: varchar("cost").default("0.00"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Hatcher tracking for breeding and incubation
export const hatcherBatches = pgTable("hatcher_batches", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  batchNumber: varchar("batch_number").notNull(),
  eggCount: integer("egg_count").notNull(),
  breed: varchar("breed"),
  incubationStartDate: timestamp("incubation_start_date").notNull(),
  expectedHatchDate: timestamp("expected_hatch_date").notNull(),
  actualHatchDate: timestamp("actual_hatch_date"),
  hatchedCount: integer("hatched_count").default(0),
  hatchRate: varchar("hatch_rate").default("0"),
  temperature: varchar("temperature"),
  humidity: varchar("humidity"),
  status: varchar("status").default("incubating"), // incubating, hatching, completed, failed
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// QR Code tracking for cages and chickens
export const qrCodes = pgTable("qr_codes", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  qrCodeId: varchar("qr_code_id").unique().notNull(),
  entityType: varchar("entity_type").notNull(), // cage, chicken, equipment
  entityId: varchar("entity_id").notNull(),
  label: varchar("label"),
  description: text("description"),
  location: varchar("location"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Cages management
export const cages = pgTable("cages", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  cageNumber: varchar("cage_number").notNull(),
  capacity: integer("capacity").notNull(),
  currentOccupancy: integer("current_occupancy").default(0),
  location: varchar("location"),
  cageType: varchar("cage_type"), // laying, breeding, chick, isolation
  qrCodeId: varchar("qr_code_id"),
  status: varchar("status").default("active"), // active, maintenance, retired
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User roles for multi-user access
export const userRoles = pgTable("user_roles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  farmId: varchar("farm_id").notNull(),
  role: varchar("role").notNull(), // admin, manager, worker, viewer
  permissions: text("permissions"), // JSON string of permissions
  assignedBy: varchar("assigned_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Farm management for multi-user access
export const farms = pgTable("farms", {
  id: varchar("id").primaryKey(),
  name: varchar("name").notNull(),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  address: text("address"),
  contactInfo: text("contact_info"),
  licenseNumber: varchar("license_number"),
  capacity: integer("capacity"),
  isActive: boolean("is_active").default(true),
  settings: text("settings"), // JSON string for farm-specific settings
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertChickenSchema = createInsertSchema(chickens).omit({
  id: true,
  userId: true,
  createdAt: true,
});

export const insertEggProductionSchema = createInsertSchema(eggProduction).omit({
  id: true,
  userId: true,
  createdAt: true,
});

export const insertSalesSchema = createInsertSchema(sales).omit({
  id: true,
  userId: true,
  createdAt: true,
});

export const insertExpenseSchema = createInsertSchema(expenses).omit({
  id: true,
  userId: true,
  createdAt: true,
});

export const insertInventorySchema = createInsertSchema(inventory).omit({
  id: true,
  userId: true,
  createdAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  userId: true,
  createdAt: true,
});

// Insert schemas for new features
export const insertHealthLogSchema = createInsertSchema(healthLogs).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFeedingScheduleSchema = createInsertSchema(feedingSchedules).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFeedingLogSchema = createInsertSchema(feedingLogs).omit({
  id: true,
  userId: true,
  createdAt: true,
});

export const insertHatcherBatchSchema = createInsertSchema(hatcherBatches).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertQRCodeSchema = createInsertSchema(qrCodes).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCageSchema = createInsertSchema(cages).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFarmSchema = createInsertSchema(farms).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserRoleSchema = createInsertSchema(userRoles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Type definitions
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Chicken = typeof chickens.$inferSelect;
export type InsertChicken = z.infer<typeof insertChickenSchema>;
export type EggProduction = typeof eggProduction.$inferSelect;
export type InsertEggProduction = z.infer<typeof insertEggProductionSchema>;
export type Sales = typeof sales.$inferSelect;
export type InsertSales = z.infer<typeof insertSalesSchema>;
export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Inventory = typeof inventory.$inferSelect;
export type InsertInventory = z.infer<typeof insertInventorySchema>;
export type WeeklyReport = typeof weeklyReports.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

// New feature types
export type HealthLog = typeof healthLogs.$inferSelect;
export type InsertHealthLog = z.infer<typeof insertHealthLogSchema>;
export type FeedingSchedule = typeof feedingSchedules.$inferSelect;
export type InsertFeedingSchedule = z.infer<typeof insertFeedingScheduleSchema>;
export type FeedingLog = typeof feedingLogs.$inferSelect;
export type InsertFeedingLog = z.infer<typeof insertFeedingLogSchema>;
export type HatcherBatch = typeof hatcherBatches.$inferSelect;
export type InsertHatcherBatch = z.infer<typeof insertHatcherBatchSchema>;
export type QRCode = typeof qrCodes.$inferSelect;
export type InsertQRCode = z.infer<typeof insertQRCodeSchema>;
export type Cage = typeof cages.$inferSelect;
export type InsertCage = z.infer<typeof insertCageSchema>;
export type Farm = typeof farms.$inferSelect;
export type InsertFarm = z.infer<typeof insertFarmSchema>;
export type UserRole = typeof userRoles.$inferSelect;
export type InsertUserRole = z.infer<typeof insertUserRoleSchema>;
