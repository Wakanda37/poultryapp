import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertChickenSchema, insertEggProductionSchema, insertSalesSchema, insertExpenseSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User resource management routes
  app.post('/api/user/add-resources', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { eggs = 0, hens = 0, money = "0" } = req.body;
      
      await storage.addUserResources(userId, eggs, hens, money);
      const updatedUser = await storage.getUser(userId);
      
      res.json({
        message: "Resources added successfully",
        user: updatedUser
      });
    } catch (error) {
      console.error("Error adding resources:", error);
      res.status(500).json({ message: "Failed to add resources" });
    }
  });

  app.put('/api/user/eggs/:amount', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const amount = parseInt(req.params.amount);
      
      await storage.updateUserEggs(userId, amount);
      const updatedUser = await storage.getUser(userId);
      
      res.json({
        message: "Egg count updated successfully",
        user: updatedUser
      });
    } catch (error) {
      console.error("Error updating egg count:", error);
      res.status(500).json({ message: "Failed to update egg count" });
    }
  });

  app.put('/api/user/hens/:amount', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const amount = parseInt(req.params.amount);
      
      await storage.updateUserHens(userId, amount);
      const updatedUser = await storage.getUser(userId);
      
      res.json({
        message: "Hen count updated successfully",
        user: updatedUser
      });
    } catch (error) {
      console.error("Error updating hen count:", error);
      res.status(500).json({ message: "Failed to update hen count" });
    }
  });

  app.put('/api/user/balance/:amount', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const amount = req.params.amount;
      
      await storage.updateUserBalance(userId, amount);
      const updatedUser = await storage.getUser(userId);
      
      res.json({
        message: "Balance updated successfully",
        user: updatedUser
      });
    } catch (error) {
      console.error("Error updating balance:", error);
      res.status(500).json({ message: "Failed to update balance" });
    }
  });

  // Chickens Routes
  app.get("/api/chickens", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const chickens = await storage.getChickens(userId);
      res.json(chickens);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chickens" });
    }
  });

  app.get("/api/chickens/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const chicken = await storage.getChickenById(userId, id);
      if (!chicken) {
        return res.status(404).json({ message: "Chicken not found" });
      }
      res.json(chicken);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chicken" });
    }
  });

  app.post("/api/chickens", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const chickenData = insertChickenSchema.parse(req.body);
      const chicken = await storage.createChicken(userId, chickenData);
      
      // Update user's hen count
      const user = await storage.getUser(userId);
      if (user) {
        await storage.updateUserHens(userId, (user.totalHens || 0) + 1);
      }
      
      res.status(201).json(chicken);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create chicken" });
    }
  });

  app.put("/api/chickens/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const updates = insertChickenSchema.partial().parse(req.body);
      const chicken = await storage.updateChicken(userId, id, updates);
      if (!chicken) {
        return res.status(404).json({ message: "Chicken not found" });
      }
      res.json(chicken);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update chicken" });
    }
  });

  app.delete("/api/chickens/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteChicken(userId, id);
      if (!deleted) {
        return res.status(404).json({ message: "Chicken not found" });
      }
      
      // Update user's hen count
      const user = await storage.getUser(userId);
      if (user && (user.totalHens || 0) > 0) {
        await storage.updateUserHens(userId, user.totalHens - 1);
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete chicken" });
    }
  });

  // Egg Production Routes
  app.get("/api/production", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const production = await storage.getEggProduction(userId);
      res.json(production);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch production data" });
    }
  });

  app.post("/api/production", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const productionData = insertEggProductionSchema.parse({
        ...req.body,
        date: new Date(req.body.date),
      });
      const production = await storage.createEggProduction(userId, productionData);
      
      // Update user's total eggs
      const user = await storage.getUser(userId);
      if (user) {
        await storage.updateUserEggs(userId, (user.totalEggs || 0) + productionData.eggCount);
      }
      
      res.status(201).json(production);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating egg production:", error);
      res.status(500).json({ message: "Failed to create egg production record" });
    }
  });

  app.put("/api/production/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const updates = insertEggProductionSchema.partial().parse({
        ...req.body,
        date: req.body.date ? new Date(req.body.date) : undefined,
      });
      const production = await storage.updateEggProduction(userId, id, updates);
      if (!production) {
        return res.status(404).json({ message: "Production record not found" });
      }
      res.json(production);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update production record" });
    }
  });

  app.delete("/api/production/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteEggProduction(userId, id);
      if (!deleted) {
        return res.status(404).json({ message: "Production record not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete production record" });
    }
  });

  // Sales Routes
  app.get("/api/sales", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sales = await storage.getSales(userId);
      res.json(sales);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sales data" });
    }
  });

  app.post("/api/sales", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const salesData = insertSalesSchema.parse({
        ...req.body,
        date: new Date(req.body.date),
        pricePerEgg: req.body.pricePerEgg || "0.132",
        totalAmount: req.body.totalAmount || (parseFloat(req.body.pricePerEgg || "0.132") * req.body.quantity).toFixed(2),
        paymentStatus: req.body.paymentStatus || "Paid",
      });
      const sale = await storage.createSales(userId, salesData);
      
      // Update user's egg count (subtract sold eggs)
      const user = await storage.getUser(userId);
      if (user && user.totalEggs && user.totalEggs >= salesData.quantity) {
        await storage.updateUserEggs(userId, user.totalEggs - salesData.quantity);
      }
      
      res.status(201).json(sale);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating sale:", error);
      res.status(500).json({ message: "Failed to create sale record" });
    }
  });

  app.put("/api/sales/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const updates = insertSalesSchema.partial().parse({
        ...req.body,
        date: req.body.date ? new Date(req.body.date) : undefined,
      });
      const sale = await storage.updateSales(userId, id, updates);
      if (!sale) {
        return res.status(404).json({ message: "Sale record not found" });
      }
      res.json(sale);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update sale record" });
    }
  });

  app.delete("/api/sales/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteSales(userId, id);
      if (!deleted) {
        return res.status(404).json({ message: "Sale record not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete sale record" });
    }
  });

  // Expenses Routes
  app.get("/api/expenses", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const expenses = await storage.getExpenses(userId);
      res.json(expenses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch expenses" });
    }
  });

  app.post("/api/expenses", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const expenseData = insertExpenseSchema.parse({
        ...req.body,
        date: new Date(req.body.date),
      });
      const expense = await storage.createExpense(userId, expenseData);
      res.status(201).json(expense);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating expense:", error);
      res.status(500).json({ message: "Failed to create expense record" });
    }
  });

  // Inventory Routes
  app.get("/api/inventory", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const inventory = await storage.getInventory(userId);
      res.json(inventory);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch inventory" });
    }
  });

  app.get("/api/inventory/balance", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const balance = await storage.getCurrentInventoryBalance(userId);
      res.json({ balance });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch inventory balance" });
    }
  });

  // Weekly Reports Routes
  app.get("/api/reports/weekly", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reports = await storage.getWeeklyReports(userId);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch weekly reports" });
    }
  });

  app.post("/api/reports/weekly", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { weekStart, weekEnd } = req.body;
      const report = await storage.createWeeklyReport(userId, new Date(weekStart), new Date(weekEnd));
      res.status(201).json(report);
    } catch (error) {
      console.error("Error creating weekly report:", error);
      res.status(500).json({ message: "Failed to create weekly report" });
    }
  });

  // Dashboard Stats
  app.get("/api/dashboard/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(today.getDate() + 1);

      const weekStart = new Date(today);
      weekStart.setDate(today.getDate() - today.getDay());
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);

      const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
      const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0);

      const [
        allChickens,
        todayProduction,
        todaySales,
        todayExpenses,
        weeklyProduction,
        weeklySales,
        weeklyExpenses,
        monthlyProduction,
        monthlySales,
        monthlyExpenses,
        currentInventory,
        user
      ] = await Promise.all([
        storage.getChickens(userId),
        storage.getEggProductionByDateRange(userId, today, tomorrow),
        storage.getSalesByDateRange(userId, today, tomorrow),
        storage.getExpensesByDateRange(userId, today, tomorrow),
        storage.getEggProductionByDateRange(userId, weekStart, weekEnd),
        storage.getSalesByDateRange(userId, weekStart, weekEnd),
        storage.getExpensesByDateRange(userId, weekStart, weekEnd),
        storage.getEggProductionByDateRange(userId, monthStart, monthEnd),
        storage.getSalesByDateRange(userId, monthStart, monthEnd),
        storage.getExpensesByDateRange(userId, monthStart, monthEnd),
        storage.getCurrentInventoryBalance(userId),
        storage.getUser(userId)
      ]);

      const todayEggs = todayProduction.reduce((sum: number, p: any) => sum + p.eggCount, 0);
      const todayEggsSold = todaySales.reduce((sum: number, s: any) => sum + s.quantity, 0);
      const todayRevenue = todaySales.reduce((sum: number, s: any) => sum + parseFloat(s.totalAmount), 0);
      const todayExpenseAmount = todayExpenses.reduce((sum: number, e: any) => sum + parseFloat(e.amount), 0);

      const weeklyEggs = weeklyProduction.reduce((sum: number, p: any) => sum + p.eggCount, 0);
      const weeklyRevenue = weeklySales.reduce((sum: number, s: any) => sum + parseFloat(s.totalAmount), 0);
      const weeklyExpenseAmount = weeklyExpenses.reduce((sum: number, e: any) => sum + parseFloat(e.amount), 0);

      const monthlyEggs = monthlyProduction.reduce((sum: number, p: any) => sum + p.eggCount, 0);
      const monthlyRevenue = monthlySales.reduce((sum: number, s: any) => sum + parseFloat(s.totalAmount), 0);
      const monthlyExpenseAmount = monthlyExpenses.reduce((sum: number, e: any) => sum + parseFloat(e.amount), 0);

      const stats = {
        totalChickens: allChickens.length,
        todayEggs,
        todayEggsSold,
        todayRevenue: todayRevenue.toFixed(2),
        todayExpenses: todayExpenseAmount.toFixed(2),
        todayProfit: (todayRevenue - todayExpenseAmount).toFixed(2),
        currentInventory,
        weeklyProduction: weeklyEggs,
        weeklyRevenue: weeklyRevenue.toFixed(2),
        weeklyExpenses: weeklyExpenseAmount.toFixed(2),
        weeklyProfit: (weeklyRevenue - weeklyExpenseAmount).toFixed(2),
        monthlyProduction: monthlyEggs,
        monthlyRevenue: monthlyRevenue.toFixed(2),
        monthlyExpenses: monthlyExpenseAmount.toFixed(2),
        monthlyProfit: (monthlyRevenue - monthlyExpenseAmount).toFixed(2),
        avgDailyProduction: monthlyEggs > 0 ? Math.round(monthlyEggs / new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate()) : 0,
        currentBalance: user?.balance || "0.00",
        totalEggs: user?.totalEggs || 0,
        totalHens: user?.totalHens || 0,
        farmName: user?.farmName || "My Poultry Farm"
      };

      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}