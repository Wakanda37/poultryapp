import { 
  users,
  chickens, 
  eggProduction, 
  sales, 
  expenses,
  inventory,
  weeklyReports,
  notifications,
  type User,
  type UpsertUser,
  type Chicken, 
  type InsertChicken,
  type EggProduction,
  type InsertEggProduction,
  type Sales,
  type InsertSales,
  type Expense,
  type InsertExpense,
  type Inventory,
  type InsertInventory,
  type WeeklyReport,
  type Notification,
  type InsertNotification
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserBalance(userId: string, amount: string): Promise<void>;

  // Chickens
  getChickens(userId: string): Promise<Chicken[]>;
  getChickenById(userId: string, id: number): Promise<Chicken | undefined>;
  createChicken(userId: string, chicken: InsertChicken): Promise<Chicken>;
  updateChicken(userId: string, id: number, updates: Partial<InsertChicken>): Promise<Chicken | undefined>;
  deleteChicken(userId: string, id: number): Promise<boolean>;

  // Egg Production
  getEggProduction(userId: string): Promise<EggProduction[]>;
  getEggProductionByDateRange(userId: string, startDate: Date, endDate: Date): Promise<EggProduction[]>;
  createEggProduction(userId: string, production: InsertEggProduction): Promise<EggProduction>;
  updateEggProduction(userId: string, id: number, updates: Partial<InsertEggProduction>): Promise<EggProduction | undefined>;
  deleteEggProduction(userId: string, id: number): Promise<boolean>;

  // Sales
  getSales(userId: string): Promise<Sales[]>;
  getSalesByDateRange(userId: string, startDate: Date, endDate: Date): Promise<Sales[]>;
  createSales(userId: string, sale: InsertSales): Promise<Sales>;
  updateSales(userId: string, id: number, updates: Partial<InsertSales>): Promise<Sales | undefined>;
  deleteSales(userId: string, id: number): Promise<boolean>;

  // Expenses
  getExpenses(userId: string): Promise<Expense[]>;
  getExpensesByDateRange(userId: string, startDate: Date, endDate: Date): Promise<Expense[]>;
  createExpense(userId: string, expense: InsertExpense): Promise<Expense>;
  updateExpense(userId: string, id: number, updates: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(userId: string, id: number): Promise<boolean>;

  // Inventory
  getInventory(userId: string): Promise<Inventory[]>;
  getCurrentInventoryBalance(userId: string): Promise<number>;
  createInventoryMovement(userId: string, movement: InsertInventory): Promise<Inventory>;
  getInventoryByDateRange(userId: string, startDate: Date, endDate: Date): Promise<Inventory[]>;

  // Weekly Reports
  getWeeklyReports(userId: string): Promise<WeeklyReport[]>;
  createWeeklyReport(userId: string, weekStart: Date, weekEnd: Date): Promise<WeeklyReport>;
  getLatestWeeklyReport(userId: string): Promise<WeeklyReport | undefined>;

  // Notifications
  getNotifications(userId: string): Promise<Notification[]>;
  createNotification(userId: string, notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(userId: string, id: number): Promise<void>;

  // Health Logs
  getHealthLogs(userId: string): Promise<HealthLog[]>;
  getHealthLogById(userId: string, id: number): Promise<HealthLog | undefined>;
  createHealthLog(userId: string, healthLog: InsertHealthLog): Promise<HealthLog>;
  updateHealthLog(userId: string, id: number, updates: Partial<InsertHealthLog>): Promise<HealthLog | undefined>;
  deleteHealthLog(userId: string, id: number): Promise<boolean>;

  // Feeding Schedules
  getFeedingSchedules(userId: string): Promise<FeedingSchedule[]>;
  getFeedingScheduleById(userId: string, id: number): Promise<FeedingSchedule | undefined>;
  createFeedingSchedule(userId: string, schedule: InsertFeedingSchedule): Promise<FeedingSchedule>;
  updateFeedingSchedule(userId: string, id: number, updates: Partial<InsertFeedingSchedule>): Promise<FeedingSchedule | undefined>;
  deleteFeedingSchedule(userId: string, id: number): Promise<boolean>;

  // Feeding Logs
  getFeedingLogs(userId: string): Promise<FeedingLog[]>;
  getFeedingLogsByDateRange(userId: string, startDate: Date, endDate: Date): Promise<FeedingLog[]>;
  createFeedingLog(userId: string, feedingLog: InsertFeedingLog): Promise<FeedingLog>;
  updateFeedingLog(userId: string, id: number, updates: Partial<InsertFeedingLog>): Promise<FeedingLog | undefined>;
  deleteFeedingLog(userId: string, id: number): Promise<boolean>;

  // Hatcher Batches
  getHatcherBatches(userId: string): Promise<HatcherBatch[]>;
  getHatcherBatchById(userId: string, id: number): Promise<HatcherBatch | undefined>;
  createHatcherBatch(userId: string, batch: InsertHatcherBatch): Promise<HatcherBatch>;
  updateHatcherBatch(userId: string, id: number, updates: Partial<InsertHatcherBatch>): Promise<HatcherBatch | undefined>;
  deleteHatcherBatch(userId: string, id: number): Promise<boolean>;

  // QR Codes
  getQRCodes(userId: string): Promise<QRCode[]>;
  getQRCodeById(userId: string, qrCodeId: string): Promise<QRCode | undefined>;
  createQRCode(userId: string, qrCode: InsertQRCode): Promise<QRCode>;
  updateQRCode(userId: string, id: number, updates: Partial<InsertQRCode>): Promise<QRCode | undefined>;
  deleteQRCode(userId: string, id: number): Promise<boolean>;

  // Cages
  getCages(userId: string): Promise<Cage[]>;
  getCageById(userId: string, id: number): Promise<Cage | undefined>;
  createCage(userId: string, cage: InsertCage): Promise<Cage>;
  updateCage(userId: string, id: number, updates: Partial<InsertCage>): Promise<Cage | undefined>;
  deleteCage(userId: string, id: number): Promise<boolean>;

  // Farms (Multi-user access)
  getFarms(userId: string): Promise<Farm[]>;
  getFarmById(userId: string, farmId: string): Promise<Farm | undefined>;
  createFarm(userId: string, farm: InsertFarm): Promise<Farm>;
  updateFarm(userId: string, farmId: string, updates: Partial<InsertFarm>): Promise<Farm | undefined>;
  deleteFarm(userId: string, farmId: string): Promise<boolean>;

  // User Roles (Admin functionality)
  getUserRoles(userId: string): Promise<UserRole[]>;
  getUserRole(userId: string, farmId: string): Promise<UserRole | undefined>;
  createUserRole(userId: string, userRole: InsertUserRole): Promise<UserRole>;
  updateUserRole(userId: string, id: number, updates: Partial<InsertUserRole>): Promise<UserRole | undefined>;
  deleteUserRole(userId: string, id: number): Promise<boolean>;

  // Admin functions
  getAllUsers(): Promise<User[]>;
  isUserAdmin(userId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserBalance(userId: string, amount: string): Promise<void> {
    await db
      .update(users)
      .set({ balance: amount, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  async updateUserEggs(userId: string, eggs: number): Promise<void> {
    await db
      .update(users)
      .set({ totalEggs: eggs, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  async updateUserHens(userId: string, hens: number): Promise<void> {
    await db
      .update(users)
      .set({ totalHens: hens, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  async addUserResources(userId: string, eggs: number = 0, hens: number = 0, money: string = "0"): Promise<void> {
    const user = await this.getUser(userId);
    if (user) {
      const newEggs = (user.totalEggs || 0) + eggs;
      const newHens = (user.totalHens || 0) + hens;
      const newBalance = (parseFloat(user.balance || "0") + parseFloat(money)).toFixed(2);
      
      await db
        .update(users)
        .set({ 
          totalEggs: newEggs,
          totalHens: newHens,
          balance: newBalance,
          updatedAt: new Date() 
        })
        .where(eq(users.id, userId));
    }
  }

  // Chickens
  async getChickens(userId: string): Promise<Chicken[]> {
    return await db.select().from(chickens).where(eq(chickens.userId, userId));
  }

  async getChickenById(userId: string, id: number): Promise<Chicken | undefined> {
    const [chicken] = await db
      .select()
      .from(chickens)
      .where(and(eq(chickens.userId, userId), eq(chickens.id, id)));
    return chicken || undefined;
  }

  async createChicken(userId: string, chicken: InsertChicken): Promise<Chicken> {
    const [newChicken] = await db
      .insert(chickens)
      .values({ ...chicken, userId })
      .returning();
    return newChicken;
  }

  async updateChicken(userId: string, id: number, updates: Partial<InsertChicken>): Promise<Chicken | undefined> {
    const [updatedChicken] = await db
      .update(chickens)
      .set(updates)
      .where(and(eq(chickens.userId, userId), eq(chickens.id, id)))
      .returning();
    return updatedChicken || undefined;
  }

  async deleteChicken(userId: string, id: number): Promise<boolean> {
    const result = await db
      .delete(chickens)
      .where(and(eq(chickens.userId, userId), eq(chickens.id, id)));
    return result.rowCount > 0;
  }

  // Egg Production
  async getEggProduction(userId: string): Promise<EggProduction[]> {
    return await db
      .select()
      .from(eggProduction)
      .where(eq(eggProduction.userId, userId))
      .orderBy(desc(eggProduction.date));
  }

  async getEggProductionByDateRange(userId: string, startDate: Date, endDate: Date): Promise<EggProduction[]> {
    return await db
      .select()
      .from(eggProduction)
      .where(
        and(
          eq(eggProduction.userId, userId),
          gte(eggProduction.date, startDate),
          lte(eggProduction.date, endDate)
        )
      )
      .orderBy(desc(eggProduction.date));
  }

  async createEggProduction(userId: string, production: InsertEggProduction): Promise<EggProduction> {
    const [newProduction] = await db
      .insert(eggProduction)
      .values({ ...production, userId })
      .returning();

    // Create inventory movement for eggs produced
    await this.createInventoryMovement(userId, {
      date: production.date,
      movementType: 'PRODUCTION',
      quantity: production.eggCount,
      balanceAfter: await this.getCurrentInventoryBalance(userId) + production.eggCount,
      notes: `Eggs collected at ${production.collectionTime}`,
      relatedId: newProduction.id,
    });

    return newProduction;
  }

  async updateEggProduction(userId: string, id: number, updates: Partial<InsertEggProduction>): Promise<EggProduction | undefined> {
    const [updatedProduction] = await db
      .update(eggProduction)
      .set(updates)
      .where(and(eq(eggProduction.userId, userId), eq(eggProduction.id, id)))
      .returning();
    return updatedProduction || undefined;
  }

  async deleteEggProduction(userId: string, id: number): Promise<boolean> {
    const result = await db
      .delete(eggProduction)
      .where(and(eq(eggProduction.userId, userId), eq(eggProduction.id, id)));
    return result.rowCount > 0;
  }

  // Sales
  async getSales(userId: string): Promise<Sales[]> {
    return await db
      .select()
      .from(sales)
      .where(eq(sales.userId, userId))
      .orderBy(desc(sales.date));
  }

  async getSalesByDateRange(userId: string, startDate: Date, endDate: Date): Promise<Sales[]> {
    return await db
      .select()
      .from(sales)
      .where(
        and(
          eq(sales.userId, userId),
          gte(sales.date, startDate),
          lte(sales.date, endDate)
        )
      )
      .orderBy(desc(sales.date));
  }

  async createSales(userId: string, sale: InsertSales): Promise<Sales> {
    const pricePerEgg = sale.pricePerEgg || "0.132"; // Default egg price
    const totalAmount = sale.totalAmount || (parseFloat(pricePerEgg) * sale.quantity).toFixed(2);
    
    const [newSale] = await db
      .insert(sales)
      .values({ 
        ...sale, 
        userId, 
        pricePerEgg,
        totalAmount 
      })
      .returning();

    // Create inventory movement for eggs sold
    const currentBalance = await this.getCurrentInventoryBalance(userId);
    await this.createInventoryMovement(userId, {
      date: sale.date,
      movementType: 'SALE',
      quantity: -sale.quantity,
      balanceAfter: currentBalance - sale.quantity,
      notes: `Sold to ${sale.customerName}`,
      relatedId: newSale.id,
    });

    // Update user balance
    const user = await this.getUser(userId);
    if (user) {
      const newBalance = (parseFloat(user.balance || "0") + parseFloat(totalAmount)).toFixed(2);
      await this.updateUserBalance(userId, newBalance);
    }

    return newSale;
  }

  async updateSales(userId: string, id: number, updates: Partial<InsertSales>): Promise<Sales | undefined> {
    const [updatedSale] = await db
      .update(sales)
      .set(updates)
      .where(and(eq(sales.userId, userId), eq(sales.id, id)))
      .returning();
    return updatedSale || undefined;
  }

  async deleteSales(userId: string, id: number): Promise<boolean> {
    const result = await db
      .delete(sales)
      .where(and(eq(sales.userId, userId), eq(sales.id, id)));
    return result.rowCount > 0;
  }

  // Expenses
  async getExpenses(userId: string): Promise<Expense[]> {
    return await db
      .select()
      .from(expenses)
      .where(eq(expenses.userId, userId))
      .orderBy(desc(expenses.date));
  }

  async getExpensesByDateRange(userId: string, startDate: Date, endDate: Date): Promise<Expense[]> {
    return await db
      .select()
      .from(expenses)
      .where(
        and(
          eq(expenses.userId, userId),
          gte(expenses.date, startDate),
          lte(expenses.date, endDate)
        )
      )
      .orderBy(desc(expenses.date));
  }

  async createExpense(userId: string, expense: InsertExpense): Promise<Expense> {
    const [newExpense] = await db
      .insert(expenses)
      .values({ ...expense, userId })
      .returning();

    // Update user balance
    const user = await this.getUser(userId);
    if (user) {
      const newBalance = (parseFloat(user.balance || "0") - parseFloat(expense.amount)).toFixed(2);
      await this.updateUserBalance(userId, newBalance);
    }

    return newExpense;
  }

  async updateExpense(userId: string, id: number, updates: Partial<InsertExpense>): Promise<Expense | undefined> {
    const [updatedExpense] = await db
      .update(expenses)
      .set(updates)
      .where(and(eq(expenses.userId, userId), eq(expenses.id, id)))
      .returning();
    return updatedExpense || undefined;
  }

  async deleteExpense(userId: string, id: number): Promise<boolean> {
    const result = await db
      .delete(expenses)
      .where(and(eq(expenses.userId, userId), eq(expenses.id, id)));
    return result.rowCount > 0;
  }

  // Inventory
  async getInventory(userId: string): Promise<Inventory[]> {
    return await db
      .select()
      .from(inventory)
      .where(eq(inventory.userId, userId))
      .orderBy(desc(inventory.date));
  }

  async getCurrentInventoryBalance(userId: string): Promise<number> {
    const inventoryRecords = await db
      .select()
      .from(inventory)
      .where(eq(inventory.userId, userId))
      .orderBy(desc(inventory.date));
    
    return inventoryRecords.length > 0 ? inventoryRecords[0].balanceAfter : 0;
  }

  async createInventoryMovement(userId: string, movement: InsertInventory): Promise<Inventory> {
    const [newMovement] = await db
      .insert(inventory)
      .values({ ...movement, userId })
      .returning();
    return newMovement;
  }

  async getInventoryByDateRange(userId: string, startDate: Date, endDate: Date): Promise<Inventory[]> {
    return await db
      .select()
      .from(inventory)
      .where(
        and(
          eq(inventory.userId, userId),
          gte(inventory.date, startDate),
          lte(inventory.date, endDate)
        )
      )
      .orderBy(desc(inventory.date));
  }

  // Weekly Reports
  async getWeeklyReports(userId: string): Promise<WeeklyReport[]> {
    return await db
      .select()
      .from(weeklyReports)
      .where(eq(weeklyReports.userId, userId))
      .orderBy(desc(weeklyReports.weekStart));
  }

  async createWeeklyReport(userId: string, weekStart: Date, weekEnd: Date): Promise<WeeklyReport> {
    // Calculate weekly statistics
    const weeklyProduction = await this.getEggProductionByDateRange(userId, weekStart, weekEnd);
    const weeklySales = await this.getSalesByDateRange(userId, weekStart, weekEnd);
    const weeklyExpenses = await this.getExpensesByDateRange(userId, weekStart, weekEnd);

    const totalEggs = weeklyProduction.reduce((sum, prod) => sum + prod.eggCount, 0);
    const totalRevenue = weeklySales.reduce((sum, sale) => sum + parseFloat(sale.totalAmount), 0);
    const totalExpenseAmount = weeklyExpenses.reduce((sum, exp) => sum + parseFloat(exp.amount), 0);
    const netProfit = totalRevenue - totalExpenseAmount;

    const [newReport] = await db
      .insert(weeklyReports)
      .values({
        userId,
        weekStart,
        weekEnd,
        totalEggs,
        totalRevenue: totalRevenue.toFixed(2),
        totalExpenses: totalExpenseAmount.toFixed(2),
        netProfit: netProfit.toFixed(2),
        notes: `Weekly report for ${weekStart.toDateString()} - ${weekEnd.toDateString()}`,
      })
      .returning();

    return newReport;
  }

  async getLatestWeeklyReport(userId: string): Promise<WeeklyReport | undefined> {
    const [report] = await db
      .select()
      .from(weeklyReports)
      .where(eq(weeklyReports.userId, userId))
      .orderBy(desc(weeklyReports.weekStart))
      .limit(1);
    return report || undefined;
  }

  // Notifications
  async getNotifications(userId: string): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(userId: string, notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db
      .insert(notifications)
      .values({ ...notification, userId })
      .returning();
    return newNotification;
  }

  async markNotificationAsRead(userId: string, id: number): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(and(eq(notifications.userId, userId), eq(notifications.id, id)));
  }
}

export const storage = new DatabaseStorage();